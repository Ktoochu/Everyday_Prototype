package com.example.everyday.data.repository;

/* 생성자를 통해 Remote/Local DataSource 를 생성하여 사용 */

import android.content.Context;

import com.example.everyday.data.dataSource.baseLocalDataSource;
import com.example.everyday.data.dataSource.baseRemoteDataSource;
import com.example.everyday.data.entity.Diary;
import com.example.everyday.data.source.baseSource;

import java.util.List;

public class baseRepository implements baseSource {

    private static baseRepository INSTANCE = null;       // 싱글톤
    private baseRemoteDataSource remoteDataSource;  // remote
    private baseLocalDataSource localDataSource;  // local

    private baseRepository(Context context) {
        remoteDataSource = baseRemoteDataSource.getInstance();
        localDataSource = baseLocalDataSource.getInstance(context);
    }

    public static baseRepository getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = new baseRepository(context);
        }

        return INSTANCE;
    }

//    @Override
    public void saveDiary(Diary diary) {
        localDataSource.saveDiary(diary);
    }

    public Diary getOne(String date) {
        return localDataSource.getOne(date);
    }

//    @Override
    public List<Diary> getAll() {
        return localDataSource.getAll();
    }

    public void update(Diary diary) { localDataSource.update(diary); }

    public void deleteById(int number) {
        localDataSource.deleteById(number);
    }

    @Override
    public void getDataItems(int page, LoadDataCallback loadDataCallback) {
        // remoteDataSource.getDataItems(page, loadDataCallback);
        localDataSource.getDataItems(page, loadDataCallback);
    }
}
