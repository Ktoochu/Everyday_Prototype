package com.example.everyday.data;

public class Item {
}
