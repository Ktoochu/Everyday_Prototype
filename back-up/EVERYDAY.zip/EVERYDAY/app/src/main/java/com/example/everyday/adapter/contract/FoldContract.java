package com.example.everyday.adapter.contract;

import android.content.Context;

import com.example.everyday.adapter.base.BasePresenter;
import com.example.everyday.adapter.base.BaseView;

public interface FoldContract {
    interface View extends BaseView<Presenter> {
        // View method
    }

    interface Presenter extends BasePresenter {
        // Presenter method
        void setView(View view);
        void setRepository(Context context);
    }
}
