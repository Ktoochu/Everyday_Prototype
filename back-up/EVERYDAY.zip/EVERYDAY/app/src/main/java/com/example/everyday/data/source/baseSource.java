package com.example.everyday.data.source;

import com.example.everyday.data.Item;
import com.example.everyday.data.entity.Diary;

import java.util.List;

/* Loader 베이스 */

public interface baseSource {

    // 콜백 리스너 세팅
    interface LoadDataCallback {
        void onDataLoaded(List<Item> items);        // 성공했을 때
        void onDataNotAvailable();                  // 데이터가 없을 때
        void onLoadFail(int code, String message);  // 실패했을 때
    }

    void getDataItems(int page, LoadDataCallback loadDataCallback);
//    void saveDiary(Diary diary);
//    List<Diary> getAll();
}
