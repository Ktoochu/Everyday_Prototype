package com.example.everyday.view.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.everyday.R;
import com.example.everyday.adapter.RecyclerDiaryListAdapter;
import com.example.everyday.adapter.RecyclerTimelineAdapter;
import com.example.everyday.data.diaryList;

import java.util.ArrayList;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class FragmentCalList extends DialogFragment implements View.OnClickListener {

    private TextView textView;
    private Button button;

    // 리스트 뷰 표시하기 위하여
    private Activity activity;
    private ArrayList<diaryList> itemList = null;
    private RecyclerDiaryListAdapter adapter = null;
    private RecyclerView recyclerView;

    public static FragmentCalList getInstance() {
        FragmentCalList cList = new FragmentCalList();
        return cList;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // 뷰 선언
        View view = inflater.inflate(R.layout.dialog, container, false);

        // 값 받아옴
        Bundle args = getArguments();
        String day = args.getString("day"); // 이걸로 데이터베이스에 접근해, 해당 날짜의 일정을 찾아볼 것이다.

        textView = (TextView) view.findViewById(R.id.ymd);
        textView.setText(day);

//        textView.setOnClickListener(this);

        // DialogFragment를 종료시키려면, 다이얼로그 바깥쪽을 터치
        // 종료하기 버튼으로도 종료시킬 수 있어야함
        // 먼저 부모 프래그먼트를 받아옵니다.
        // findFragmentByTag안의 문자열 값은 Fragment1.java에서 있던 문자열과 같아야 함.
//        private Fragment fragment;
//        fragment = getActivity().getSupportFragmentManager().findFragmentByTag("tag");
//        // 아래 코드는 버튼 이벤트 안에 넣어야 함
//        if (fragment != null) {
//            DialogFragment dialogFragment = (DialogFragment) fragment;
//            dialogFragment.dismiss(); // 종료
//        }

        // 리사이클러뷰에 표시할 데이터 리스트 생성.
        itemList = new ArrayList<>();

        // 리사이클러뷰에 LinearLayoutManager 객체 지정.
        // getView() : Fragment의 root의 view를 받아옴
        recyclerView = view.findViewById(R.id.diaryView);
        recyclerView.setLayoutManager(new LinearLayoutManager(activity));

        // 리사이클러뷰에 SimpleTextAdapter 객체 지정.
        adapter = new RecyclerDiaryListAdapter(itemList);
        recyclerView.setAdapter(adapter);

        // 아이템의 클릭 이벤트
        adapter.setOnClickListener(new RecyclerDiaryListAdapter.OnClickListner() {
            @Override
            public void OnClick(View view, int pos) {
                AlertDialog.Builder dlg = new AlertDialog.Builder(activity);

                dlg.setTitle("터치 테스트"); //제목
                dlg.setMessage(pos+"번의 목록을 터치하셨습니다"); // 메시지
                dlg.show();
            }
        });

        // 아이템 추가.
        for (int i=1; i<5; i++) {
            addItem(i) ;
        }
        // 어뎁터가 리스트뷰에 데이터가 바뀌었다고 알려준다.
        adapter.notifyDataSetChanged();

        // 뷰 리턴
        return view;
    }

    // 프래그먼트가 처음으로 액티비티에 부착 될 때 호출
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof Activity)
            activity = (Activity) context;
    }

    // 데이터 리스트에 아이템 추가
    private void addItem(int number) {
        diaryList item = new diaryList();
        item.setmNumber(number);
        itemList.add(item);
        Log.v("다이어리 암튼 그거: ", ""+itemList.size());
    }

    @Override
    public void onClick(View view) {
//        AlertDialog.Builder dlg = new AlertDialog.Builder(activity);
//
//        dlg.setTitle("터치 테스트"); //제목
//        dlg.setMessage("목록을 터치하셨습니다"); // 메시지
//
//        // 버튼 클릭시 동작
//        dlg.setPositiveButton("확인",new DialogInterface.OnClickListener(){
//            public void onClick(DialogInterface dialog, int which) {
//                //토스트 메시지
//                Toast.makeText(getActivity(),"확인을 누르셨습니다.",Toast.LENGTH_SHORT).show();
//            }
//        });
//        dlg.show();
    }

}
