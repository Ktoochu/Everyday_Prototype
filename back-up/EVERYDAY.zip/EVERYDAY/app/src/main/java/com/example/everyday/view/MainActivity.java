package com.example.everyday.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.everyday.R;

public class MainActivity extends AppCompatActivity {

    private Button signUp, signIn;
    private EditText id, pass;

    private Intent intent;

    // 초기 화면, 로그인 창.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //안드로이드 3.0 부터는 mainactivity에서 인터넷 연결시 필요
        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 8) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        signIn = (Button) findViewById(R.id.signIn);
        signUp = (Button) findViewById(R.id.signUp);
        id = (EditText) findViewById(R.id.id);
        pass = (EditText) findViewById(R.id.pass);

        // 로그인 하기
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // 홈 액티비티 열어준다.
                intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
            }
        });
    }
}