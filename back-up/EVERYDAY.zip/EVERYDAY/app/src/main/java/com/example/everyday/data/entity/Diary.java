package com.example.everyday.data.entity;

import org.jetbrains.annotations.NotNull;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "diary", primaryKeys = {"id", "diaryNumber"})
public class Diary {
//    @PrimaryKey
    @NotNull
    public Long id;

    @NotNull
    public Integer diaryNumber;

//    @ColumnInfo(name = "title")
//    public String title;

//    @ColumnInfo(name = "file")
//    public String file;

    @ColumnInfo(name = "content")
    public String content;

    @ColumnInfo(name = "date")
    public String date;

    @ColumnInfo(name = "time")
    public String time;

    @ColumnInfo(name = "isChange")
    public Boolean isChange;

    @NotNull
    public Long getId() { return id; }

    public void setId(@NotNull Long id) {
        this.id = id;
    }

    @NotNull
    public Integer getDiaryNumber() {
        return diaryNumber;
    }

    public void setDiaryNumber(@NotNull Integer diaryNumber) {
        this.diaryNumber = diaryNumber;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }

    public String getTime() { return time; }

    public void setTime(String time) { this.time = time; }

    public Boolean getIsChange() { return isChange; }

    public void setIsChange(Boolean isChange) { this.isChange = isChange; }
}
