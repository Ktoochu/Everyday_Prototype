package com.example.everyday.data.dataSource;

import com.example.everyday.data.source.baseSource;

/* 서버 데이터 소스 정의 */

public class baseRemoteDataSource implements baseSource {

    private static baseRemoteDataSource INSTANCE;   // 싱글톤
    // private final FlickrService flickrService;

    private baseRemoteDataSource() {
        // flickrService = RetrofitCreator.createRetrofit().create(FlickrService.class);
    }

    // 인스턴스 반환
    public static baseRemoteDataSource getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new baseRemoteDataSource();
        }

        return INSTANCE;
    }

    @Override
    public void getDataItems(int page, LoadDataCallback loadDataCallback) {
//        final Task task = TASKS_SERVICE_DATA.get(taskId);
//
//        // Simulate network by delaying the execution.
//        Handler handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                callback.onTaskLoaded(task);
//            }
//        }, SERVICE_LATENCY_IN_MILLIS);
    }
}
