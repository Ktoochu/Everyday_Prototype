package com.example.everyday.data.local;

import android.content.Context;

import com.example.everyday.data.entity.Diary;
import com.example.everyday.data.entity.Member;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Diary.class, Member.class}, version = 1, exportSchema = false)
public abstract class LocalDatabase extends RoomDatabase {
    public abstract MemberDao memberDao();
    public abstract DiaryDao diaryDao();

    // singleton, 데이터베이스를 매번 생성하는 건 리소스를 많이 사용
    private static LocalDatabase INSTANCE = null;

    public static LocalDatabase getDatabase(final Context context) {
        // 데이터베이스 인스턴스를 가져와 반환
        if (INSTANCE == null) {
            synchronized (LocalDatabase.class) {
                INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                        LocalDatabase.class, "everyday-database")
                        .build();
            }
        }
        return INSTANCE;
    }

}
