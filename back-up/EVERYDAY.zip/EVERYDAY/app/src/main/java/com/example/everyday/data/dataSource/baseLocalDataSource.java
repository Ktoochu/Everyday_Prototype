package com.example.everyday.data.dataSource;

/* 로컬 데이터 소스 정의 */

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.everyday.data.entity.Diary;
import com.example.everyday.data.local.LocalDatabase;
import com.example.everyday.data.source.baseSource;

import java.util.List;

import androidx.lifecycle.Observer;

// AsyncTask를 사용해서 비동기적으로 구현하는 방법 필요
public class baseLocalDataSource implements baseSource {

    private static baseLocalDataSource INSTANCE;   // 싱글톤
    private static LocalDatabase db;
    private static List<Diary> mDiaries;

    // 나중에 세션으로 받아올, 사용자 아이디 (로그인 후 저장)
    private static Long id = 0L;
    private static int number = 0;

    private baseLocalDataSource(Context context) {
        // Dao 생성 : @Dao interface Dao
        // @Query("SELECT * FROM Tasks")
        // List<Task> getTasks();

        db = LocalDatabase.getDatabase(context);
    }

    // 인스턴스 반환
    public static baseLocalDataSource getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = new baseLocalDataSource(context);
        }

        return INSTANCE;
    }

//    @Override
    public void saveDiary(Diary diary) {
        Log.v("로컬 데이터베이스 소스 테스트", "일기 저장.");
//        db.diaryDao().Insert(diary);
        new InsertAsyncTask().execute(diary);
    }

//    @Override
//    public List<Diary> getAll() {
//        Log.v("로컬 데이터베이스 소스 테스트", "모든 일기 보기.");
//
//        db.diaryDao().getAll().observe(this, new Observer<List<Diary>>() {
//            @Override
//            public void onChanged(List<Diary> diaries) {
//                mDiaries = diaries;
//            }
//        });
//
//        return mDiaries;
//    }

    public Diary getOne(String date) {
        Diary diary = null;

        try {
            diary = new getOneAsyncTask().execute(date).get();
        } catch (Exception e) {
            Log.v("로컬 데이터베이스 소스 테스트", "일기 읽어오기 에러 01");
        }
        return diary;
    }

    public List<Diary> getAll() {
        try {
            mDiaries = new getAllAsyncTask().execute().get();
        } catch (Exception e) {
            Log.v("로컬 데이터베이스 소스 테스트", "일기 읽어오기 에러 02");
        }
        return mDiaries;
    }

    public void update(Diary diary) {
        new updateAsyncTask().execute(diary);
    }

    public void deleteById(int dNumber) {
        new deleteByIdAsyncTask().execute(dNumber);
        Log.v("로컬 데이터베이스 소스 테스트", "일기 삭제.");
    }

    @Override
    public void getDataItems(int page, LoadDataCallback loadDataCallback) {
        Log.v("로컬 데이터베이스 소스 테스트", "잘 작동중입니다.");
        // db.memberDao().getAll();
//        Runnable activateRunnable = new Runnable() {
//            @Override
//            public void run() {
//                Dao.쿼리함수();
//            }
//        };
//        mAppExecutors.diskIO().execute(activateRunnable);
    }

    // UI 스레드에서  DB 접근할 수 없음(java.lang.IllegalStateException: Cannot access database on the main thread since it may potentially lock the UI for a long period of time)
    // AsyncTask를 사용 (출처: https://m.blog.naver.com/rjs5730/221302132817)
    public static class InsertAsyncTask extends AsyncTask<Diary, Void, Void> {
        @Override //백그라운드작업(메인스레드 X)
        protected Void doInBackground(Diary... diaries) {
            number = db.diaryDao().getCount(id);

            diaries[0].setId(id);
            diaries[0].setDiaryNumber(number);
            diaries[0].setIsChange(false);
            db.diaryDao().Insert(diaries[0]);
            return null;
        }
    }

    public static class getOneAsyncTask extends AsyncTask<String, Void, Diary> {
        @Override
        protected Diary doInBackground(String... strings) {
            return db.diaryDao().getOne(id, strings[0]);
        }
    }

    public static class getAllAsyncTask extends AsyncTask<Void, Void, List<Diary>> {
        @Override
        protected List<Diary> doInBackground(Void... voids) {
            return db.diaryDao().getAll();
        }
    }

    public static class updateAsyncTask extends AsyncTask<Diary, Void, Void> {
        @Override
        protected Void doInBackground(Diary... diaries) {
            number = db.diaryDao().getCount(id);

            diaries[0].setId(id);
            diaries[0].setIsChange(true);
            db.diaryDao().update(diaries[0]);
            return null;
        }
    }

    public static class deleteByIdAsyncTask extends AsyncTask<Integer, Void, Void> {
        @Override
        protected Void doInBackground(Integer... integers) {
            db.diaryDao().deleteById(id, integers[0]);
            return null;
        }
    }
}
