package com.example.everyday.data.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "member")
public class Member {
    @PrimaryKey
    public int id;

    @ColumnInfo(name = "loginId")
    public String loginId;

    @ColumnInfo(name = "password")
    public String password;

    @ColumnInfo(name = "name")
    public String name;

    @ColumnInfo(name = "email")
    public String email;

    @ColumnInfo(name = "addr")
    public String addr;

    @ColumnInfo(name = "phone")
    public String phone;

    @ColumnInfo(name = "regdate")
    public String regdate;
}
