package com.example.everyday.view.fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.everyday.R;
import com.example.everyday.adapter.contract.FoldContract;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

// 폴더를 관리할 프래그먼트
public class FragmentFold extends Fragment implements FoldContract.View {

    private Activity activity;
    private FoldContract.Presenter mPresenter;       // View에서 전달된 이벤트에 대한 처리를 한다(View와 무관한 처리만 한다)

    // 생성자 호출되면 새 클래스 반환
    public static FragmentFold newInstance() {
        return new FragmentFold();
    }

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.file, container, false);
    }

    @Override
    public void setPresenter(FoldContract.Presenter presenter) {
        mPresenter = presenter;
    }

    // 프래그먼트가 처음으로 액티비티에 부착 될 때 호출
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof Activity)
            activity = (Activity) context;
    }
}
