package com.example.everyday.view.fragment;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.everyday.R;
import com.example.everyday.adapter.RecyclerTimelineAdapter;
import com.example.everyday.adapter.contract.HomeContract;
import com.example.everyday.data.timeline;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

// 홈 화면을 나타내줄 프래그먼트
public class FragmentHome extends Fragment implements HomeContract.View {

    private Activity activity;
    private HomeContract.Presenter mPresenter;       // View에서 전달된 이벤트에 대한 처리를 한다(View와 무관한 처리만 한다)

    private ArrayList<timeline> itemList = null;
    private RecyclerTimelineAdapter adapter = null;
    private RecyclerView recyclerView;

    // 생성자 호출되면 새 클래스 반환
    public static FragmentHome newInstance() {
        return new FragmentHome();
    }

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.home, container, false);

        // 리사이클러뷰에 표시할 데이터 리스트 생성.
        itemList = new ArrayList<>();

        // 리사이클러뷰에 LinearLayoutManager 객체 지정.
        // getView() : Fragment의 root의 view를 받아옴
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(activity));

        // 리사이클러뷰에 SimpleTextAdapter 객체 지정.
        adapter = new RecyclerTimelineAdapter(itemList);
        recyclerView.setAdapter(adapter);

        // 아이템 추가.
        for (int i=0; i<30; i++) {
            addItem(getResources().getDrawable(R.drawable.circle), i+"번째 일정", "0000-00-00") ;
        }

        // 어뎁터가 리스트뷰에 데이터가 바뀌었다고 알려준다.
        //출처: https://androbook.tistory.com/entry/충격과-경악의-삽질 [Good Life]
        adapter.notifyDataSetChanged();

        return view;
    }

    @Override
    public void setPresenter(HomeContract.Presenter presenter) {
        mPresenter = presenter;
    }

    // 프래그먼트가 처음으로 액티비티에 부착 될 때 호출
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof Activity)
            activity = (Activity) context;
    }

    // 데이터 리스트에 아이템 추가
    private void addItem(Drawable icon, String title, String desc) {
        timeline item = new timeline();

        item.setmIcon(icon);
        item.setmTitle(title);
        item.setnDesc(desc);

        itemList.add(item);
    }
}
