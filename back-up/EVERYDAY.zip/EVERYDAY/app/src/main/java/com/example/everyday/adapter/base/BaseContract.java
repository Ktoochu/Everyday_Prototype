package com.example.everyday.adapter.base;

// 하나의 interface에 View/Presenter을 정의하고, 이를 각각의 View와 Presenter에서 정의

import android.content.Context;

public interface BaseContract {

    interface View extends BaseView<Presenter> {
        // View method
    }

    interface Presenter extends BasePresenter {
        // Presenter method
        void setView(View view);
        void setRepository(Context context);
    }

}
