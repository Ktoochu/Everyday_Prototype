package com.example.everyday.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.everyday.R;
import com.example.everyday.data.timeline;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerTimelineAdapter extends RecyclerView.Adapter<RecyclerTimelineAdapter.ViewHolder> {

    private ArrayList<timeline> mData = null ;

    // 아이템 뷰를 저장하는 뷰홀더 클래스.
    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView icon;
        TextView title;
        TextView desc;

        ViewHolder(View itemView) {
            super(itemView) ;

            // 뷰 객체에 대한 참조. (hold strong reference)
            icon = itemView.findViewById(R.id.icon) ;
            title =itemView.findViewById(R.id.title);
            desc = itemView.findViewById(R.id.desc);
        }
    }

    // 생성자에서 데이터 리스트 객체를 받아서 저장
    public RecyclerTimelineAdapter(ArrayList<timeline> list) {
        mData = list ;
    }

    // 아이템 뷰를 위한 뷰홀더 객체 생성하여 리턴
    @NonNull
    @Override
    public RecyclerTimelineAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext() ;
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) ;

        // 뷰 생성해서 어댑터의 뷰홀더에 등록
        View view = inflater.inflate(R.layout.timeline_item, parent, false) ;
        RecyclerTimelineAdapter.ViewHolder viewHolder = new RecyclerTimelineAdapter.ViewHolder(view) ;

        return viewHolder;
    }

    // position에 해당하는 데이터를 뷰홀더의 아이템뷰에 표시
    @Override
    public void onBindViewHolder(@NonNull RecyclerTimelineAdapter.ViewHolder holder, int position) {
        timeline item = mData.get(position) ;   // 해당 포지션의 아이템

        // Log.i("ITEM : ", item.getmTitle()+" "+item.getnDesc());

        // 아이템(의 데이터)을 홀더에 저장
        holder.icon.setImageDrawable(item.getmIcon()) ;
        holder.title.setText(item.getmTitle()) ;
        holder.desc.setText(item.getnDesc()) ;
    }

    // 	전체 아이템 갯수 반환
    @Override
    public int getItemCount() {
        return mData.size();
    }
}
