package com.example.everyday.data;

import android.graphics.drawable.Drawable;

/* 타임라인 아이템에 표시될 데이터를 저장하는 클래스 */

public class timeline {
    private Drawable mIcon ;
    private String mTitle ;
    private String nDesc ;


    public void setmIcon(Drawable mIcon) {
        this.mIcon = mIcon;
    }

    public void setmTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public void setnDesc(String nDesc) {
        this.nDesc = nDesc;
    }

    public Drawable getmIcon() {
        return mIcon;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getnDesc() {
        return nDesc;
    }
}
