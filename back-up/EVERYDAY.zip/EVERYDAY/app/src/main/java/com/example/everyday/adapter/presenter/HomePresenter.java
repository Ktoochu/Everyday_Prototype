package com.example.everyday.adapter.presenter;


import android.content.Context;

import com.example.everyday.adapter.contract.HomeContract;
import com.example.everyday.data.repository.baseRepository;

public class HomePresenter implements HomeContract.Presenter {

    private HomeContract.View mView = null;
    private baseRepository repository;

    public HomePresenter() {
        super();
        // repository = baseRepository.getInstance();
    }

    @Override
    public void setView(HomeContract.View view) {
        mView = view;
        mView.setPresenter(this);
    }

    @Override
    public void setRepository(Context context) {
        repository = baseRepository.getInstance(context);
    }
}
