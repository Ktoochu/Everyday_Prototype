package com.example.everyday.view;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.everyday.R;
import com.example.everyday.adapter.TabPagerAdapter;
import com.example.everyday.view.fragment.FragmentCal;
import com.example.everyday.view.fragment.FragmentFold;
import com.example.everyday.view.fragment.FragmentHome;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

// 홈 액티비티. 로그인하면 나타나는 창이다.
public class HomeActivity extends AppCompatActivity {

//    private TabLayout tab;
    private ViewPager viewPager;

    // Activity 내의 Fragment를 관리하기 위해 FragmentManager 사용
//    private FragmentManager fragmentManager = getSupportFragmentManager();
//    private FragmentCal fragmentCal = new FragmentCal();
//    private FragmentFold fragmentFold = new FragmentFold();
//    private FragmentHome fragmentHome = new FragmentHome();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);


//        FragmentTransaction transaction = fragmentManager.beginTransaction();               // FragmentTransaction 가져오기
//        transaction.replace(R.id.frameLayout, fragmentHome).commitAllowingStateLoss();      // Fragment 변경. state save 와 관계없이 작동

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomBar);                   // 하단에 탭 추가
        bottomNavigationView.setOnNavigationItemSelectedListener(new ItemSelectedListener());       // 탭 클릭되면 이벤트 실행

        TabPagerAdapter tabPagerAdapter = new TabPagerAdapter(getSupportFragmentManager());
//        tabPagerAdapter.addFragment(fragmentCal);
//        tabPagerAdapter.addFragment(fragmentFold);
//        tabPagerAdapter.addFragment(fragmentHome);

        viewPager = findViewById(R.id.viewpager);
        viewPager.setAdapter(tabPagerAdapter);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                viewPager.setCurrentItem(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    // 하단의 탭을 클릭했을 떄 실행되는 이벤트 메소드
    class ItemSelectedListener implements BottomNavigationView.OnNavigationItemSelectedListener{
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            // FragmentTransaction의 API를 사용하면 Fragment의 추가, 제거, 변경 등의 작업을 할 수 있다.
            // FragmentTransaction transaction = fragmentManager.beginTransaction();

            // 각 아이템 선택했을 때, 프래그먼트를 연결해준다.
            switch(menuItem.getItemId())
            {
                case R.id.homeItem:
                    viewPager.setCurrentItem(0);
                    //transaction.replace(R.id.frameLayout, fragmentHome).commitAllowingStateLoss();
                    break;
                case R.id.folderItem:
                    viewPager.setCurrentItem(1);
                    //transaction.replace(R.id.frameLayout, fragmentFold).commitAllowingStateLoss();
                    break;
                case R.id.calenderItem:
                    viewPager.setCurrentItem(2);
                    //transaction.replace(R.id.frameLayout, fragmentCal).commitAllowingStateLoss();
                    break;
            }
            return true;
        }
    }
}
