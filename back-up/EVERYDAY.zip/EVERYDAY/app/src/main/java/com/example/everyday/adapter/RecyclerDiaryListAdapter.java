package com.example.everyday.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.everyday.R;
import com.example.everyday.adapter.contract.CalContract;
import com.example.everyday.data.diaryList;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerDiaryListAdapter extends RecyclerView.Adapter<RecyclerDiaryListAdapter.ViewHolder> {

    public interface OnClickListner {
        void OnClick(View view, int pos);
    }

    private OnClickListner mClickListener = null;
    private ArrayList<diaryList> mDiary = null;

    // 클릭 이벤트 리스너 저장
    public void setOnClickListener(OnClickListner onClickListener) {
        mClickListener = onClickListener;
    }


    // 아이템뷰를 저장하는 뷰홀더 클래스
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView number;

        ViewHolder(View itemView) {
            super(itemView);
            number = itemView.findViewById(R.id.diaryNumber);

            // 이벤트 처리
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    // 아이템이 삭제되면 NO_POSITION 반환
                    if(position != RecyclerView.NO_POSITION) {
                        if(mClickListener != null) {
                            mClickListener.OnClick(view, position);
                        }
                    }
                }
            });
        }

    }

    public RecyclerDiaryListAdapter(ArrayList<diaryList> list) { mDiary = list; }

    @NonNull
    @Override
    // 아이템 뷰를 위한 뷰홀더 객체 생성하여 리턴
    public RecyclerDiaryListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext() ;
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) ;

        // 뷰 생성해서 어댑터의 뷰홀더에 등록
        View view = inflater.inflate(R.layout.diarylist_item, parent, false) ;
        RecyclerDiaryListAdapter.ViewHolder viewHolder = new RecyclerDiaryListAdapter.ViewHolder(view) ;

        return viewHolder;
    }

    @Override
    // position에 해당하는 데이터를 뷰홀더의 아이템뷰에 표시
    public void onBindViewHolder(@NonNull RecyclerDiaryListAdapter.ViewHolder holder, int position) {
        diaryList item = mDiary.get(position);
        String text = ""+item.getmNumber();
        Log.v("다이어리 암튼 그거: ", position+" "+item.getmNumber());
        holder.number.setText(text);
    }

    @Override
    public int getItemCount() {
        return mDiary.size();
    }
}
