package com.example.everyday.view.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.everyday.R;
import com.example.everyday.adapter.contract.CalContract;
import com.example.everyday.data.entity.Diary;
import com.example.everyday.view.DiaryInsertActivity;

import org.jetbrains.annotations.NotNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import static android.app.Activity.RESULT_OK;

// 캘린더를 표시할 프래그먼트
    /*
        Contract : View와 Presenter에 대한 interface을 작성
        Presenter : Contract.Presenter을 상속받아서 구현
        View : Contract.View을 상속받아서 구현
    */
public class FragmentCal extends Fragment implements CalContract.View {

    private Activity activity;
    private CalContract.Presenter mPresenter;       // View에서 전달된 이벤트에 대한 처리를 한다(View와 무관한 처리만 한다)

    // 날짜 형식, 새 일기 추가할 때 할당해준다
    // java.util.Locale.getDefault() or Locale.KOREA
    private SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault());
    private SimpleDateFormat time = new SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault());

    private TextView textView;
    private EditText editText;
    private Button delete, update;

    private int number = -1;
    private String mode = "text";   // text 와 edit 모드

    // 생성자 호출되면 새 클래스 반환
    public static FragmentCal newInstance() {
        return new FragmentCal();
    }

    @Override
    // 프래그먼트 생성시 호출
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    // onCreate 이후에 화면을 구성할 때 호출되는 메서드
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 뷰 생성 (선언)
        final View view = inflater.inflate(R.layout.calender, container, false);
        setHasOptionsMenu(true); // 프래그먼트에서 컨텍스트 메뉴 사용하기 위해

        delete = view.findViewById(R.id.delete);
        update = view.findViewById(R.id.update);

        textView = view.findViewById(R.id.textView);
        editText = view.findViewById(R.id.editView);

        // 임시 출력
        readDiaryAll();

        // 삭제하기 버튼에 이벤트 추가하기
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 밑에 일기가 떠야만 이벤트 부여
                if (number > -1) {
                    mPresenter.deleteById(number);
                    // 일기 읽어오기 함수 호출
                    readDiaryAll();
                }
            }
        });

        // 텍스트뷰 한 번 클릭하면 수정하기(에디트뷰로 바뀜)
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 밑에 일기가 떠야만 이벤트 부여
                if (number > -1 && mode.equals("text")) {
                    editText.setVisibility(View.VISIBLE);
                    editText.setText(textView.getText().toString());
                    textView.setVisibility(View.GONE);

                    mode = "edit";
                }
            }
        });

        // ----------------------------------- [ 임시 수정하기 ] START ----------------------------------------------
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 밑에 일기가 떠야만 이벤트 부여
                if (number > -1 && mode.equals("edit")) {
                    String text = editText.getText().toString();   // getFreezesText() : 상태 저장이라고 들었다...
                    Diary mDiary = new Diary();
                    mDiary.setDiaryNumber(number);
                    mDiary.setContent(text);

                    Date regDate = new Date();
                    mDiary.setDate(date.format(regDate));
                    mDiary.setTime(time.format(regDate));
                    mPresenter.update(mDiary);

                    textView.setVisibility(View.VISIBLE);
                    editText.setVisibility(View.GONE);

                    // 일기 읽어오기 함수 호출
                    readDiaryOne(mDiary.getDate());

                    mode = "text";
                }
            }
        });
        // ----------------------------------- [ 임시 수정하기 ] END ----------------------------------------------


        // ----------------------------------- [ 캘린더 ] START ----------------------------------------------
        CalendarView calendarView = view.findViewById(R.id.calendarView);                   // 캘린더뷰 가져오기
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {      // 날짜 클릭 이벤트 리스너

            @Override
            // 년, 월, 일을 받아온다.
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {
                int rMonth = month + 1; // 00부터 시작하므로

                // 데이터를 다이얼로그로 보내는 코드
                Bundle args = new Bundle();              // 여러가지의 타입의 값을 저장하는 Map 클래스

                // date 형식에 맞춰 String 생성
                String mString = "-", dString = "-";
                if (rMonth < 10) mString = "-0";
                if (day < 10) dString = "-0";
                String ymd = "" + year + mString + rMonth + dString + day;
                args.putString("day", "" + ymd);

                FragmentCalList calList = FragmentCalList.getInstance();
                calList.setArguments(args); // 데이터 전달
                // 안드로이드 이전 버전들에서도 프래그먼트를 사용할 수 있도록 만든 appcompat_v7라이브러리 프로젝트에서 지원하는 기능
                // getActivity()라고 써야만 이 함수를 쓸 수 있다. 왜지....?
                if (getActivity() != null)
                    calList.show(getActivity().getSupportFragmentManager(), "tag");

                // ----------------------------------- [ 일기 읽어와 보여주기 ] START ----------------------------------------------
                // 밑에 데이터베이스 내용 출력
                // 일기 읽어오기 함수 호출 (-1: 일기 없음)
                number = readDiaryOne(ymd);
                // ----------------------------------- [ 일기 읽어와 보여주기 ] END ----------------------------------------------
            }
        });

        // ----------------------------------- [ 캘린더 ] END ----------------------------------------------

        // 생성한 뷰 반환
        return view;
    }

    // 프레젠터 추가
    @Override
    public void setPresenter(CalContract.Presenter presenter) {
        mPresenter = presenter;
    }

    // 프래그먼트가 처음으로 액티비티에 부착 될 때 호출
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof Activity) {
            // activity = (Activity) context;
            activity = getActivity();
            mPresenter.setRepository(activity.getApplicationContext());
        }
    }

    // fragment가 사용자에게 보여지고 실행 중일때 호출되며 사용자와 상호작용할 수 있는 상태
    @Override
    public void onResume() {
        super.onResume();

        // onCreateOptionsMenu 호출
        activity.invalidateOptionsMenu();
    }

    // 액티비티(Activity)가 시작될 때 호출되는 함수, 단 한 번만 호출됨
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // 컨텍스트 메뉴
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.newpost_menu, menu);
    }

    // 컨텍스트 메뉴 클릭시
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.newSchedule:
                Toast.makeText(activity, "새 일정 쓰기.", Toast.LENGTH_LONG).show();
                return true;

            case R.id.newDiary:
                Toast.makeText(activity, "새 일기 쓰기.", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getContext(), DiaryInsertActivity.class);
                startActivityForResult(intent, 1);
                return true;

            case R.id.allDiary:
                Toast.makeText(activity, "모든 다이어리 보기.", Toast.LENGTH_LONG).show();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    // 데이터베이스 접근 및 이용시
    public void addTest() {
        mPresenter.addTest();
    }

    // 새 액티비티(일기 쓰기)에서 결과 받아온 후에 실행되는 메서드
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case 1:
                    String text = data.getStringExtra("text");
                    Diary mDiary = new Diary();
                    mDiary.setDiaryNumber(0);
                    mDiary.setContent(text);

                    Date regDate = new Date();
                    mDiary.setDate(date.format(regDate));
                    mDiary.setTime(time.format(regDate));
                    mPresenter.save(mDiary);

                    // 일기 읽어오기 함수 호출
                    readDiaryOne(mDiary.getDate());
            }
        }
    }

    // 일기 읽어오기
    public void readDiaryAll() {
        List<Diary> diaries = mPresenter.show();

        textView.setText("");
        for (Diary diary : diaries) {
            textView.append(diary.getId() + " : " + diary.getDiaryNumber() + " : " + diary.getContent() + " : " + diary.getDate() + " 시간 - " + diary.getTime());
            if(diary.getIsChange()) {
                textView.append(" 수정됨"+"\n");
            }
        }

        Log.v("모든 일기 읽어오기 ", "총 갯수 ("+diaries.size()+")");
    }

    public int readDiaryOne(String date) {
        // 밑에 데이터베이스 내용 출력
        final Diary mDiary = mPresenter.getOne(date);

        textView.setText("");
        if (mDiary != null) {
            number = mDiary.getDiaryNumber();
            textView.append(mDiary.getId() + " : " + mDiary.getDiaryNumber() + " : " + mDiary.getContent() + " : " + mDiary.getDate() + " 시간 - " + mDiary.getTime());
            if(mDiary.getIsChange()) {
                textView.append(" 수정됨"+"\n");
            }
        } else number = -1;
        Log.v("캘린더 클릭/일기 읽어오기 ", date);

        return number;
    }
}
