package com.example.everyday.data.local;

import com.example.everyday.data.entity.Member;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface MemberDao {
    @Query("SELECT * FROM member")
    List<Member> getAll();

    @Insert
    void Insert(Member member);

    @Insert
    void insertAll(Member... Members);

    @Update
    void update(Member member);

    @Delete
    void delete(Member member);
}
