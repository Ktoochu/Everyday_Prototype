package com.example.everyday.adapter.presenter;

import android.content.Context;

import com.example.everyday.adapter.contract.CalContract;
import com.example.everyday.data.Item;
import com.example.everyday.data.entity.Diary;
import com.example.everyday.data.repository.baseRepository;
import com.example.everyday.data.source.baseSource;

import java.util.List;

// SampleContract.Presenter에서 정의한 내용을 구현
// View : loadItem을 호출합니다.
// Presenter : loadItem이 발생하면 새로운 데이터를 호출합니다.
// Presenter -> View : loadItem이 성공적으로 완료되면 updateView을 호출합니다.
// 이때 SampleContract.View의 정의되어 있는 updateView을 호출합니다.
// view : 전달된 updateView에 따라서 실제 View를 갱신합니다.
public class CalPresenter implements CalContract.Presenter {

    private CalContract.View mView = null;
    private baseRepository repository;

    public CalPresenter() {
        super();
    }

    @Override
    public void setView(CalContract.View view) {
        mView = view;
        mView.setPresenter(this);
    }

    @Override
    public void setRepository(Context context) {
        repository = baseRepository.getInstance(context);
    }

    @Override
    public void addTest() {
       repository.getDataItems(2, new baseSource.LoadDataCallback() {
           @Override
           public void onDataLoaded(List<Item> items) {

           } // 성공했을 때

           @Override
           public void onDataNotAvailable(){

           } // 데이터가 없을 때

           @Override
           public void onLoadFail(int code, String message){

           } // 실패했을 때
       }); // 식으로 레포지토리에 요청
    }

    @Override
    public void save(Diary diary) {
        repository.saveDiary(diary);
    }

    @Override
    public Diary getOne(String date) {
        return repository.getOne(date);
    }

    @Override
    public List<Diary> show() {
        return repository.getAll();
    }

    @Override
    public void update(Diary diary) {
        repository.update(diary);
    }

    @Override
    public void deleteById(int number) {
        repository.deleteById(number);
    }
}
