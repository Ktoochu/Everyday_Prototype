package com.example.everyday.adapter;

import com.example.everyday.adapter.presenter.FoldPresenter;
import com.example.everyday.adapter.presenter.HomePresenter;
import com.example.everyday.view.fragment.FragmentCal;
import com.example.everyday.view.fragment.FragmentFold;
import com.example.everyday.view.fragment.FragmentHome;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import com.example.everyday.adapter.presenter.CalPresenter;

public class TabPagerAdapter extends FragmentPagerAdapter {

    private static final int Frag_NuM = 3;  // 프래그먼트 개수

    private CalPresenter mCal;
    private HomePresenter mHome;
    private FoldPresenter mFold;

    // 생성자
    public TabPagerAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0: {
                FragmentHome home = FragmentHome.newInstance();
                mHome = new HomePresenter();
                mHome.setView(home);

                return home;
            }
            case 1: {
                FragmentFold fold = FragmentFold.newInstance();
                mFold = new FoldPresenter();
                mFold.setView(fold);

                return fold;
            }
            case 2: {
                FragmentCal cal = FragmentCal.newInstance();
                mCal = new CalPresenter();
                mCal.setView(cal);

                return cal;
            }
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return Frag_NuM;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return super.getPageTitle(position);
    }
}
