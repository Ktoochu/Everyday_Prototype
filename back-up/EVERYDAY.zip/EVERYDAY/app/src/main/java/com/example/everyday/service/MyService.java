
package com.example.everyday.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

import androidx.annotation.Nullable;

public class MyService extends Service {
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

/*
    private String id, passwd;
    private String serverIP = "192.168.219.106";
    private Socket socket;                  //소켓생성
    private PrintWriter out = null;         //서버로 데이터를 전송한다.
    private DataInputStream dos;            // 서버에서 데이터를 읽는다.

    IBinder mBinder = new MyBinder();

    public MyService() {
    }

    class MyBinder extends Binder {
        MyService getService() { // 서비스 객체를 리턴
            return MyService.this;
        }
    }

    // Service 객체와 (화면단 Activity 사이에서)
    // 통신(데이터를 주고받을) 때 사용하는 메서드
    // 데이터를 전달할 필요가 없으면 return null;
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return mBinder; // 서비스 객체를 리턴
    }

    // 서비스에서 가장 먼저 호출됨(최초에 한번만)
    @Override
    public void onCreate() {
        //소켓을 생성
        try {
            socket = new Socket(serverIP, 3002);
        } catch (IOException e) {
            android.util.Log.i("서비스 테스트 실패", "onCreate()");
            e.printStackTrace();
        }

        android.util.Log.i("서비스 테스트", "onCreate()");
        super.onCreate();
    }

    // 서비스 종료
    @Override
    public void onDestroy() {
        try {
            // 소켓 닫음
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        android.util.Log.i("서비스 테스트", "onDestroy()");
        super.onDestroy();
    }

    // 서비스가 호출될 때마다 실행
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //작업이 완료되었을 경우 stopSelf() 나 stopService() 를 호출하여 서비스를 종료하여야 합니다
        android.util.Log.i("서비스 테스트", "onStartCommand()");
        return super.onStartCommand(intent, flags, startId);
    }

    // 로그인 해주는 함수
    public String login(String serv_id, String serv_pass) {
        String mode = null;

        try {
            out = new PrintWriter(socket.getOutputStream(), true); //데이터를 전송시 stream 형태로 변환하여
            dos = new DataInputStream(socket.getInputStream());

            // 로그인 할 거라고 서버에 보냄
            out.println("login");

            // 아이디와 패스워드를 보냄
            out.println(serv_id);
            out.println(serv_pass);

            // 서버에서 답 받아옴 (mode)
            mode = dos.readUTF();

            // 로그인 실패
            if (mode.equals("fail")) ;
            else {
                // 아이디 저장
                id = serv_id;
                passwd = serv_pass;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        // 받아온 답을 리턴해준다.
        return mode;
    }

//    // 아이디 중복 체크하는 함수
//    public void DB_check(String serv_id) {
//        String isThere;
//
//        try {
//            out = new PrintWriter(socket.getOutputStream(), true); //데이터를 전송시 stream 형태로 변환하여
//            dos = new DataInputStream(socket.getInputStream());
//
//            // 로그인 할 거라고 서버에 보냄
//            out.println("DBcheck");
//
//            // 서버한테 정보 전송
//            out.println(serv_id);
//
//            // 서버에서 답 받아옴
//            isThere = dos.readUTF();
//
//            // 만약 중복이면,
//            if (isThere.equals("true"))
//                Toast.makeText(getApplicationContext(), "중복된 아이디입니다.", Toast.LENGTH_LONG).show();
//            else
//                Toast.makeText(getApplicationContext(), "사용 가능한 아이디입니다.", Toast.LENGTH_LONG).show();
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//    // 회원가입 해주는 함수
//    public void SingUP(String mode, String serv_id, String serv_pass, String serv_add, String serv_phone, String serv_enter) {
//        try {
//            out = new PrintWriter(socket.getOutputStream(), true); //데이터를 전송시 stream 형태로 변환하여
//
//            // 서버한테 정보 전송
//            out.println(mode);
//            out.println(serv_id);
//            out.println(serv_pass);
//            out.println(serv_add);
//            out.println(serv_phone);
//            out.println(serv_enter);
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
}
*/
