package com.example.everyday.adapter.contract;

import android.content.Context;

import com.example.everyday.adapter.base.BasePresenter;
import com.example.everyday.adapter.base.BaseView;
import com.example.everyday.data.entity.Diary;
import com.example.everyday.data.entity.Member;

import java.util.List;

public interface CalContract {
    interface View extends BaseView<Presenter> {
        // View method
    }

    interface Presenter extends BasePresenter {
        // Presenter method
        void setView(View view);
        void setRepository(Context context);
        void addTest();

        void save(Diary diary);
        Diary getOne(String date);
        List<Diary> show();
        void update(Diary diary);
        void deleteById(int number);
    }
}
