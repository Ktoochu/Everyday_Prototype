package com.example.everyday.data.local;

import com.example.everyday.data.entity.Diary;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface DiaryDao {

    @Query("SELECT COUNT(*) FROM diary WHERE id = :id")
    int getCount(Long id);

    @Query("SELECT * FROM diary WHERE id = :id AND date = :date")
    Diary getOne(Long id, String date);

    @Query("SELECT * FROM diary")
    List<Diary> getAll();

    @Insert
    void Insert(Diary diary);

    @Update
    void update(Diary diary);

    @Query("DELETE FROM diary WHERE id = :id AND diaryNumber = :diaryNumber")
    void deleteById(Long id, int diaryNumber);

    @Delete
    void delete(Diary diary);
}
