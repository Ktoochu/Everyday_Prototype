package com.example.everyday.adapter.presenter;


import android.content.Context;

import com.example.everyday.adapter.contract.FoldContract;
import com.example.everyday.data.repository.baseRepository;

public class FoldPresenter implements FoldContract.Presenter {

    private FoldContract.View mView = null;
    private baseRepository repository;

    public FoldPresenter() {
        super();
        // repository = baseRepository.getInstance();
    }

    @Override
    public void setView(FoldContract.View view) {
        mView = view;
        mView.setPresenter(this);
    }

    @Override
    public void setRepository(Context context) {
        repository = baseRepository.getInstance(context);
    }
}
