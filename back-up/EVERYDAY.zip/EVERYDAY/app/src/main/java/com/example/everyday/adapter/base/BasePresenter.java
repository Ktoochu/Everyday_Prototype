package com.example.everyday.adapter.base;

public interface BasePresenter {

}
