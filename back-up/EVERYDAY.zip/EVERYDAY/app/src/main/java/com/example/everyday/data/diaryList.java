package com.example.everyday.data;

public class diaryList {
    private int mNumber;
//    private String mContent;

    public int getmNumber() {
        return mNumber;
    }

    public void setmNumber(int mNumber) {
        this.mNumber = mNumber;
    }
}
